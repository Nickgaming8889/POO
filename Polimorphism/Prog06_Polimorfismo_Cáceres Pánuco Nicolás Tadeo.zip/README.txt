Requisitos del Programa:

1. Contener 1 Clase Padre (Superclase), que contenga 3 atributos y 
4 metodos virtuales (minimo).
2. Contener 3 Clases Hijo (Derivada) en las cuales se desarrollen 
los 4 metodos virtuales de la superclase (los 4 metodos virtuales 
se tienen que desarrollar en cada clase derivada).

Ejemplos para peticion de datos:

Ejemplo Car:
Marca: Toyota
Modelo: Supra Mk4
Año: 1991

Ejemplo Motocycle:
Marca: Ninja
Modelo: 200RS
Año: 2021

*Valores de ejemplo para el codigo. (El codigo cuenta con validacion de
entrada de tipo de dato 'int').