#ifndef CLASS_C
#define CLASS_C
#define WIDTH 20

#include <iostream>
#include "ClassA.h"
using namespace std;

class ClassC: ClassA {
    protected:
        //Attributes...
        string minus1;
        string minus2;
        string totalminus;

    public:
        //Methods...
        ClassC();
        string sumMinus(); 

        ~ClassC();

        string getMinus1();
        void setMinus1(string);

        string getMinus2();
        void setMinus2(string);

        string getTotal3();
        void setTotal3(string);
};

#endif