#include "ClassD.h"
#include <iostream>
using namespace std;

int main() {
    
    ClassD one;

    
    one.allCharacter();

    return 0;
}
